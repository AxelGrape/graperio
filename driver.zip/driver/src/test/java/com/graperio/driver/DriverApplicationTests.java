package com.graperio.driver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriverApplicationTests {

	@Test
	void contextLoads() {
	}

}
